import { NextRequest, NextResponse } from "next/server";

// Mock multiple startup data
const startupData = {
  agriculture: [
    {
      id: 1,
      name: "AgriTech Solutions",
      funding: "$5M",
      market: "Crop Monitoring",
      growth: "Fast",
      revenue: "$1.2M",
      innovation: "AI-powered Soil Analysis",
    },
    {
      id: 2,
      name: "Green Harvest",
      funding: "$10M",
      market: "Precision Farming",
      growth: "Steady",
      revenue: "$3.5M",
      innovation: "Smart Irrigation Systems",
    },
    {
      id: 3,
      name: "Farm2Table",
      funding: "$3M",
      market: "Organic Distribution",
      growth: "Expanding",
      revenue: "$900K",
      innovation: "Direct-to-Consumer AgriTech",
    },
  ],
};

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const industry = searchParams.get("industry");

  if (!industry || !startupData[industry]) {
    return NextResponse.json({ error: "Industry not found" }, { status: 404 });
  }

  return NextResponse.json(startupData[industry]);
}
